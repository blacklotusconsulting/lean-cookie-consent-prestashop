<?php

header('Location: ../');
exit;

